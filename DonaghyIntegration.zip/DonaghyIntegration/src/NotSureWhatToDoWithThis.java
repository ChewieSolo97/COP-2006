// I don't need this, but it was in the PSI so...
class NotSureWhatToDoWithThis {
  private String useless = "useless";
  private int why;

  public int getWhy() {
    return why;
  }

  public String getUseless() {
    return useless;
  }

  public void setWhy(int why2) {
    why = why2;
  }

  public void setUseless(String useless2) {
    useless = useless2;
  }
}
